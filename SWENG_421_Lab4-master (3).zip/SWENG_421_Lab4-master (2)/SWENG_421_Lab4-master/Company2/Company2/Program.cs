﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company2
{
    class Program
    {
        static void Main(string[] args)
        {
            XYZ company = new XYZ(new Utility("QuickSort"));

            company.AddProduct(new Product(123, "Red Shoe", 12.50));
            company.AddProduct(new Product(1234, "black Shoe", 12.50));

            company.Utility.Sort(company.GetProducts());
           
            Console.Read();
        }
    }
}
