﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company2
{
    class Program
    {
        static void Main(string[] args)
        {
            XYZ company = new XYZ(new Utility());

            company.AddProduct(new Product(123, "Red Shoe", 12.50));
            company.AddProduct(new Product(1234, "black Shoe", 12.50));
            company.AddProduct(new Product(124, "white Shoe", 12.50));
            company.AddProduct(new Product(12354, "pink Shoe", 12.50));
            company.AddProduct(new Product(12, "orange Shoe", 12.50));


            company.Utility.Sort(company.GetProducts());
           
            Console.Read();
        }
    }
}
