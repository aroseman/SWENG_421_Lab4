﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company2
{
    class Utility
    {
        string SortName;
        public Utility(string sortName)
        {
            this.SortName = sortName; 
        }
        public Utility()
        {
            this.SortName = "QuickSort";
        }
        public List<ProductIF> Sort(List<ProductIF> data)
        {
            List<ProductIF> sortedList = new List<ProductIF>();
            if(SortName != "QuickSort")
            {
                var type = Type.GetType(SortName);
                Sort sorter = (Sort)Activator.CreateInstance(type);
                sortedList = sorter.sort(data);
            }
            else
            {
                Sort sorter = new QuickSort("QuickSort");
                sortedList = sorter.sort(data);
            }
            return sortedList;
        }
    }
}
