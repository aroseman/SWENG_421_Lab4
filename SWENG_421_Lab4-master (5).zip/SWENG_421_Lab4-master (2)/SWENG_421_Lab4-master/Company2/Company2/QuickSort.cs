﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company2
{
    class QuickSort : Sort
    {
        //Product[] productArray;
        public QuickSort(string sortName) : base(sortName)
        {
        }

        public override List<ProductIF> sort(List<ProductIF> data)
        {



            Console.WriteLine("Does the QuickSort");
            //productArray = data.Cast<Product>.ToArray();
            //List<Product> products = new List<Product>();
            //productArray = data.ConvertAll(Product).ToArray();


            int myleft = 0, myright = data.Count-1;
            mySort(data.Cast<Product>().ToList(), myleft, myright);

            foreach(Product prod in data)
            {
                Console.WriteLine(prod.GetID() + "  " + prod.GetName() + "  " + prod.GetPrice());
            }
            return data;
        }
        private List<Product> mySort(List<Product> prods, int left, int right)
        {
            if (left < right)
            {
                int pivot = parti(prods, left, right);

                if (pivot > 1)
                {
                    mySort(prods, left, pivot - 1);
                }
                if (pivot + 1 < right)
                {
                    mySort(prods, pivot + 1, right);
                }
            }

            return prods;

        }
        private int parti(List<Product> prods, int left, int right)
        {
            int pivot = prods[left].GetID();
            while (true)
            {
                while (prods[left].GetID() < pivot)
                {
                    left++;
                }
                while (prods[right].GetID() > pivot)
                {
                    right--;
                }
                if (left < right)
                {
                    if (prods[left] == prods[right])
                        return right;

                    Product temp = prods[left];
                    prods[left] = prods[right];
                    prods[right] = temp;
                }
                else
                {
                    return right;
                }





            }
        }
    }
}
